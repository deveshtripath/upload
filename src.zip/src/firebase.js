// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDZ1f-LOB89s9jsbuBqafnZ3LCal-WXaOA",
    authDomain: "upload-3d923.firebaseapp.com",
    projectId: "upload-3d923",
    storageBucket: "upload-3d923.appspot.com",
    messagingSenderId: "184139430218",
    appId: "1:184139430218:web:d2387f50b19a57a6de29b3",
    measurementId: "G-Q9W1TP1X1C"
};